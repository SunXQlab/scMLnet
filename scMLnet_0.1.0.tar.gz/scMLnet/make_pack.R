library(devtools)
library(roxygen2)

### after add/modify code 
document() 
## creat NAMESPACE

##
check()

##
build()
